CloudFront Endpoint URL : https://d9mfzrxrvvmoi.cloudfront.net

S3 website-endpoint URL : http://my628462118132bucket.s3-website-us-east-1.amazonaws.com